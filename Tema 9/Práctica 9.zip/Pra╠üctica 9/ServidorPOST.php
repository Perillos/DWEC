<?php

$val1 = (int)$_POST['val1'];
$val2 = (int)$_POST['val2'];
 

echo "Tu código secreto es: ".($val1+$val2);
