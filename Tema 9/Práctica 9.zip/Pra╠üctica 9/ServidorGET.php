<?php

$val1 = (int)$_GET['val1'];
$val2 = (int)$_GET['val2'];
 

echo "Tu código secreto es: ".($val1+$val2);
