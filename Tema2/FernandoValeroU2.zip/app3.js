const dateFirst = new Date(2000, 1, 1, 0, 0, 0, 0);

const dateSecon = new Date();

const pasTimiDates = dateSecon - dateFirst

let spanH3 = document.getElementById("diagonal")

spanH3.innerHTML = pasTimiDates